<?php
/*
Plugin Name: Monitor Sensores Ematel
Description: Sistema monitoreo sensores de temperatura y humedad.
Version: 2.0
Author: Fabian Aramis Sanchez Cardinale
*/

defined('ABSPATH') or die('Acceso no permitido');

class SensorMonitorPremium {
    private $db;
    
    public function __construct() {
        add_shortcode('sensor_premium', [$this, 'mostrar_dashboard']);
        add_action('wp_enqueue_scripts', [$this, 'cargar_recursos']);
        add_action('wp_head', [$this, 'incluir_estilos']);
        add_action('wp_ajax_get_sensor_data', [$this, 'get_sensor_data_ajax']);
        add_action('wp_ajax_nopriv_get_sensor_data', [$this, 'get_sensor_data_ajax']);
        add_action('wp_ajax_get_full_sensor_data', [$this, 'get_full_sensor_data_ajax']);
        add_action('wp_ajax_nopriv_get_full_sensor_data', [$this, 'get_full_sensor_data_ajax']);
    }
    
    private function conectar_db() {
        if(!$this->db) {
            $this->db = new mysqli('82.25.79.89', 'datasensor_farmacia', 'Ematel2025*', 'test_nodered');
            
            if($this->db->connect_error) {
                error_log("Error conexión BD: ".$this->db->connect_error);
                return false;
            }
            $this->db->set_charset("utf8mb4");
        }
        return $this->db;
    }
    
    public function cargar_recursos() {
        // Chart.js con animaciones
        wp_enqueue_script('chart-js', 'https://cdn.jsdelivr.net/npm/chart.js', [], '3.9.1', true);
        
        // Font Awesome para íconos
        wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css');
        
        // Nuestro JS con AJAX
        wp_enqueue_script('sensor-premium-js', plugins_url('sensor-premium.js', __FILE__), ['chart-js', 'jquery'], '2.5', true);
        
        // Variables para AJAX
        wp_localize_script('sensor-premium-js', 'sensorPremium', [
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('sensor_premium_nonce')
        ]);
    }
    
    public function incluir_estilos() {
        ?>
        <style>
            /* ESTILOS PRINCIPALES */
            .sensor-dashboard-premium {
                max-width: 1200px;
                margin: 0 auto;
                font-family: 'Segoe UI', 'Roboto', 'Helvetica Neue', Arial, sans-serif;
                color: #333;
                padding: 20px;
            }
            
            /* Alertas */
            .alertas-container {
                margin-bottom: 25px;
                display: grid;
                gap: 10px;
            }
            
            .alerta {
                padding: 15px 20px;
                border-radius: 8px;
                display: flex;
                align-items: center;
                font-weight: 500;
                opacity: 0;
                transform: translateY(10px);
                transition: all 0.5s ease;
            }
            
            .alerta.show {
                opacity: 1;
                transform: translateY(0);
            }
            
            .alerta i {
                margin-right: 12px;
                font-size: 1.2em;
            }
            
            .alerta.critica {
                background-color: #FFEBEE;
                border-left: 4px solid #F44336;
                color: #D32F2F;
            }
            
            .alerta.advertencia {
                background-color: #FFF8E1;
                border-left: 4px solid #FFC107;
                color: #FF8F00;
            }
            
            /* Grid principal */
            .sensor-grid-premium {
                display: grid;
                grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                gap: 25px;
            }
            
            /* Cards de sensores */
            .sensor-card-premium {
                border-radius: 12px;
                overflow: hidden;
                box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
                transition: all 0.3s ease;
                background: white;
                position: relative;
            }
            
            .sensor-card-premium:hover {
                transform: translateY(-5px);
                box-shadow: 0 10px 25px rgba(0, 0, 0, 0.12);
            }
            
            .sensor-card-premium.temp {
                border-top: 4px solid #FF5252;
            }
            
            .sensor-card-premium.hum {
                border-top: 4px solid #4285F4;
            }
            
            .sensor-card-premium.estado-critico {
                animation: pulse 2s infinite;
            }
            
            .sensor-card-premium.estado-alerta {
                animation: pulseSoft 3s infinite;
            }
            
            /* Header del card */
            .card-header-premium {
                padding: 20px;
                display: flex;
                align-items: center;
                border-bottom: 1px solid rgba(0, 0, 0, 0.05);
                position: relative;
            }
            
            .card-icon-premium {
                width: 50px;
                height: 50px;
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                margin-right: 15px;
                font-size: 1.5em;
            }
            
            .temp .card-icon-premium {
                background-color: rgba(255, 82, 82, 0.1);
                color: #FF5252;
            }
            
            .hum .card-icon-premium {
                background-color: rgba(66, 133, 244, 0.1);
                color: #4285F4;
            }
            
            .card-header-premium h3 {
                margin: 0;
                font-size: 1.3em;
                font-weight: 600;
            }
            
            .card-badge-premium {
                position: absolute;
                right: 20px;
                top: 20px;
                background: rgba(0, 0, 0, 0.05);
                padding: 5px 10px;
                border-radius: 20px;
                font-size: 0.8em;
                font-weight: 500;
            }
            
            /* Valor principal */
            .card-value-premium {
                padding: 20px;
                font-size: 3em;
                font-weight: 700;
                text-align: center;
                line-height: 1;
            }
            
            .card-value-premium small {
                font-size: 0.6em;
                opacity: 0.7;
            }
            
            .temp .card-value-premium {
                color: #FF5252;
            }
            
            .hum .card-value-premium {
                color: #4285F4;
            }
            
            /* Estadísticas */
            .card-stats-premium {
                display: grid;
                grid-template-columns: repeat(3, 1fr);
                padding: 0 20px 20px;
                gap: 15px;
            }
            
            .stat-premium {
                text-align: center;
                padding: 10px;
                background: rgba(0, 0, 0, 0.02);
                border-radius: 8px;
            }
            
            .stat-premium span {
                display: block;
                font-size: 0.8em;
                color: #666;
                margin-bottom: 5px;
            }
            
            .stat-premium strong {
                font-size: 1.2em;
                font-weight: 600;
            }
            
            /* Footer del card */
            .card-footer-premium {
                padding: 15px 20px;
                background: rgba(0, 0, 0, 0.02);
                border-top: 1px solid rgba(0, 0, 0, 0.05);
                font-size: 0.85em;
                color: #666;
            }
            
            /* Gráfico */
            .sensor-chart-premium {
                grid-column: span 2;
                background: white;
                border-radius: 12px;
                box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
                padding: 20px;
            }
            
            .chart-header-premium {
                display: flex;
                justify-content: space-between;
                align-items: center;
                margin-bottom: 20px;
            }
            
            .chart-header-premium h4 {
                margin: 0;
                font-size: 1.2em;
                font-weight: 600;
            }
            
            .chart-legends-premium {
                display: flex;
                gap: 20px;
            }
            
            .legend-premium {
                font-size: 0.9em;
                display: flex;
                align-items: center;
            }
            
            .legend-premium i {
                margin-right: 5px;
                font-size: 0.8em;
            }
            
            .legend-premium.temp {
                color: #FF5252;
            }
            
            .legend-premium.hum {
                color: #4285F4;
            }
            
            /* Tabla de histórico */
/* Contenedor de la tabla */
.history-table-container {
    grid-column: span 2; /* Hace que el contenedor ocupe dos columnas en el grid */
    margin-top: 30px;
    background: white;
    border-radius: 12px;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
    padding: 20px;
    overflow-x: auto; /* Permite el desplazamiento horizontal si es necesario */
    width: 100%; /* Asegura que el contenedor ocupe todo el ancho disponible */
    box-sizing: border-box; /* Incluye el padding en el cálculo del ancho */
margin-left: 5px;


}

/* Tabla */
.history-table {
    width: 100%; /* Asegura que la tabla ocupe todo el ancho */
    border-collapse: collapse;
    table-layout: auto; /* Permite que las columnas se ajusten automáticamente */
}

/* Celdas */
.history-table th, .history-table td {
    padding: 12px 15px;
    text-align: left;
    border-bottom: 1px solid #eee;
    word-wrap: break-word; /* Ajusta el texto largo dentro de las celdas */
}

/* Encabezado */
.history-table th {
    background-color: #f9f9f9;
    font-weight: 600;
    color: #555;
}

/* Hover en filas */
.history-table tr:hover {
    background-color: #f5f5f5;
}                                               

/* Estilos para los badges de estado */
.status-badge {
    display: inline-block;
    padding: 4px 8px;
    border-radius: 12px;
    font-size: 0.8em;
    font-weight: 500;
}

.status-badge.normal {
    background-color: #E8F5E9;
    color: #2E7D32;
}

.status-badge.warning {
    background-color: #FFF8E1;
    color: #FF8F00;
}

.status-badge.danger {
    background-color: #FFEBEE;
    color: #D32F2F;
}

            
            /* Botón Ver Más */
            .view-more-btn {
                display: block;
                width: 100%;
                max-width: 200px;
                margin: 20px auto 0;
                padding: 12px;
                background-color: #4285F4;
                color: white;
                border: none;
                border-radius: 6px;
                font-size: 1em;
                font-weight: 500;
                text-align: center;
                cursor: pointer;
                transition: all 0.3s ease;
            }
            
            .view-more-btn:hover {
                background-color: #3367D6;
                transform: translateY(-2px);
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            }
            
            /* Modal */
            .sensor-modal-premium {
                display: none;
                position: fixed;
                z-index: 1000;
                left: 0;
                top: 0;
                width: 100%;
                height: 100%;
                overflow: auto;
                background-color: rgba(0,0,0,0.8);
            }
            
            .modal-content-premium {
                background-color: #fefefe;
                margin: 5% auto;
                padding: 30px;
                border-radius: 12px;
                width: 90%;
                max-width: 1200px;
                max-height: 80vh;
                overflow-y: auto;
                box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
            }
            
            .close-modal-premium {
                color: #aaa;
                float: right;
                font-size: 28px;
                font-weight: bold;
                cursor: pointer;
                transition: color 0.3s;
            }
            
            .close-modal-premium:hover {
                color: #555;
            }
            
            .full-data-table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 20px;
            }
            
            .full-data-table th, .full-data-table td {
                padding: 12px 15px;
                text-align: left;
                border-bottom: 1px solid #eee;
            }
            
            .full-data-table th {
                background-color: #f5f5f5;
                font-weight: 600;
                color: #555;
                position: sticky;
                top: 0;
            }
            
            .full-data-table tr:nth-child(even) {
                background-color: #f9f9f9;
            }
            
            .full-data-table tr:hover {
                background-color: #f1f1f1;
            }
            
            /* Animaciones */
            @keyframes pulse {
                0% { box-shadow: 0 0 0 0 rgba(244, 67, 54, 0.4); }
                70% { box-shadow: 0 0 0 10px rgba(244, 67, 54, 0); }
                100% { box-shadow: 0 0 0 0 rgba(244, 67, 54, 0); }
            }
            
            @keyframes pulseSoft {
                0% { box-shadow: 0 0 0 0 rgba(255, 193, 7, 0.4); }
                70% { box-shadow: 0 0 0 8px rgba(255, 193, 7, 0); }
                100% { box-shadow: 0 0 0 0 rgba(255, 193, 7, 0); }
            }
            
            @keyframes fadeIn {
                from { opacity: 0; }
                to { opacity: 1; }
            }
            
            /* Responsive */
            @media (max-width: 1024px) {
                .sensor-grid-premium {
                    grid-template-columns: 1fr;
                }
                
                .sensor-chart-premium {
                    grid-column: span 1;
                }
            }
            
            @media (max-width: 768px) {
                .card-stats-premium {
                    grid-template-columns: 1fr;
                }
                
                .chart-legends-premium {
                    flex-direction: column;
                    gap: 5px;
                }
            }
            
            @media (max-width: 480px) {
                .card-value-premium {
                    font-size: 2.5em;
                }
                
                .modal-content-premium {
                    width: 95%;
                    padding: 15px;
                }
            }
            /* Estilo general para la tabla */
.full-data-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
    font-family: 'Segoe UI', Arial, sans-serif;
    font-size: 14px;
    color: #333;
    background-color: #fff;
    border-radius: 8px;
    overflow: hidden;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
}

/* Encabezado de la tabla */
.full-data-table th {
    background-color: #4285F4; /* Color de fondo del encabezado */
    color: #fff; /* Color del texto */
    font-weight: bold;
    text-align: left;
    padding: 12px 15px;
    position: sticky; /* Fija el encabezado al hacer scroll */
    top: 0;
    z-index: 1;
}

/* Filas de la tabla */
.full-data-table td {
    padding: 12px 15px;
    border-bottom: 1px solid #eee;
    text-align: left;
    word-wrap: break-word; /* Ajusta el texto largo dentro de las celdas */
}

/* Alternar colores en las filas */
.full-data-table tr:nth-child(even) {
    background-color: #f9f9f9; /* Color de fondo para filas pares */
}

.full-data-table tr:nth-child(odd) {
    background-color: #fff; /* Color de fondo para filas impares */
}

/* Hover en las filas */
.full-data-table tr:hover {
    background-color: #f1f1f1; /* Color de fondo al pasar el mouse */
    transition: background-color 0.3s ease;
}

/* Ajuste de texto en las celdas */
.full-data-table td:first-child,
.full-data-table th:first-child {
    text-align: center; /* Centrar la primera columna */
}

/* Botón de cierre del modal */
.close-modal-premium {
    color: #aaa;
    float: right;
    font-size: 24px;
    font-weight: bold;
    cursor: pointer;
    transition: color 0.3s;
}

.close-modal-premium:hover {
    color: #555;
}

/* Responsive para pantallas pequeñas */
@media (max-width: 768px) {
    .full-data-table {
        font-size: 12px; /* Reducir el tamaño de la fuente */
    }

    .full-data-table th, .full-data-table td {
        padding: 8px 10px; /* Reducir el padding */
    }
}
        </style>
        <?php
    }
    
    public function mostrar_dashboard($atts) {
        $local = $atts['local'] ?? '001';
        
        $db = $this->conectar_db();
        if(!$db) return '<div class="sensor-error">Error de conexión a la base de datos</div>';
        
        $local_escaped = $db->real_escape_string($local);
        
        // Obtener últimos datos
        $temp_data = $db->query(
            "SELECT * FROM datasensor_farmacia 
            WHERE sensor LIKE '%temp%' 
            AND local = '$local_escaped'
            ORDER BY fecha DESC LIMIT 1"
        )->fetch_assoc();
        
        $hum_data = $db->query(
            "SELECT * FROM datasensor_farmacia 
            WHERE sensor LIKE '%hum%' 
            AND local = '$local_escaped'
            ORDER BY fecha DESC LIMIT 1"
        )->fetch_assoc();
        
        // Verificar alertas
        $alertas = $this->verificar_alertas($temp_data, $hum_data);
        
        ob_start();
        ?>
        <div class="sensor-dashboard-premium" data-local="<?= esc_attr($local) ?>">
            
            <?php if(!empty($alertas)): ?>
            <div class="alertas-container">
                <?php foreach($alertas as $alerta): ?>
                <div class="alerta <?= esc_attr($alerta['tipo']) ?>">
                    <i class="<?= esc_attr($alerta['icono']) ?>"></i>
                    <span><?= esc_html($alerta['mensaje']) ?></span>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
            
            <div class="sensor-grid-premium">
                
                <!-- Card de Temperatura -->
                <div class="sensor-card-premium temp <?= $this->get_card_status($temp_data['medida'], $temp_data['min'], $temp_data['max'], false) ?>">
                    <div class="card-header-premium">
                        <div class="card-icon-premium">
                            <i class="fas fa-thermometer-half"></i>
                        </div>
                        <h3>Temperatura</h3>
                        <div class="card-badge-premium">Local <?= esc_html($local) ?></div>
                    </div>
                    <div class="card-value-premium">
                        <?= esc_html($temp_data['medida']) ?> <small>°C</small>
                    </div>
                    <div class="card-stats-premium">
                        <div class="stat-premium">
                            <span>Máx</span>
                            <strong><?= esc_html($temp_data['max']) ?>°</strong>
                        </div>
                        <div class="stat-premium">
                            <span>Mín</span>
                            <strong><?= esc_html($temp_data['min']) ?>°</strong>
                        </div>
                        <div class="stat-premium">
                            <span>Estado</span>
                            <strong><?= $this->get_status_text($temp_data['medida'], $temp_data['min'], $temp_data['max'], false) ?></strong>
                        </div>
                    </div>
                    <div class="card-footer-premium">
                        <span class="hora">Actualizado: <?= esc_html($this->formatear_fecha($temp_data['fecha'])) ?></span>
                    </div>
                </div>
                
                <!-- Card de Humedad -->
                <div class="sensor-card-premium hum <?= $this->get_card_status($hum_data['medida'], $hum_data['min'], $hum_data['max'], true) ?>">
                    <div class="card-header-premium">
                        <div class="card-icon-premium">
                            <i class="fas fa-tint"></i>
                        </div>
                        <h3>Humedad</h3>
                        <div class="card-badge-premium">Local <?= esc_html($local) ?></div>
                    </div>
                    <div class="card-value-premium">
                        <?= esc_html($hum_data['medida']) ?> <small>%</small>
                    </div>
                    <div class="card-stats-premium">
                        <div class="stat-premium">
                            <span>Máx</span>
                            <strong><?= esc_html($hum_data['max']) ?>%</strong>
                        </div>
                        <div class="stat-premium">
                            <span>Mín</span>
                            <strong><?= esc_html($hum_data['min']) ?>%</strong>
                        </div>
                        <div class="stat-premium">
                            <span>Estado</span>
                            <strong><?= $this->get_status_text($hum_data['medida'], $hum_data['min'], $hum_data['max'], true) ?></strong>
                        </div>
                    </div>
                    <div class="card-footer-premium">
                        <span class="hora">Actualizado: <?= esc_html($this->formatear_fecha($hum_data['fecha'])) ?></span>
                    </div>
                </div>
                
                <!-- Gráfico Interactivo -->
                <div class="sensor-chart-premium">
                    <div class="chart-header-premium">
                        <h4>Historial de Datos</h4>
                        <div class="chart-legends-premium">
                            <span class="legend-premium temp"><i class="fas fa-circle"></i> Temperatura</span>
                            <span class="legend-premium hum"><i class="fas fa-circle"></i> Humedad</span>
                        </div>
                    </div>
                    <canvas id="sensorChart-<?= esc_attr($local) ?>"></canvas>
                </div>
                
                <!-- Histórico de Datos -->
                <div class="history-table-container">
                    <h4>Registros Recientes</h4>
                    <table class="history-table">
                        <thead>
                            <tr>
                                <th>Fecha</th>
                                <th>Sensor</th>
                                <th>Valor</th>
                                <th>Estado</th>
                            </tr>
                        </thead>
                        <tbody id="history-table-body">
                            <!-- Los datos se cargarán via AJAX -->
                        </tbody>
                    </table>
                    <button class="view-more-btn" id="view-sensor-info-btn">Ver información de los sensores</button>                </div>
            </div>
                        
       <!-- Modal para mostrar información de los sensores -->
       <div id="sensorInfoModal" class="sensor-modal-premium">
    <div class="modal-content-premium">
        <span class="close-modal-premium">&times;</span>
        <h2>Información de los Sensores</h2>
        <table class="full-data-table">
            <thead>
                <tr>
                    <th>Cliente</th>
                    <th>Local</th>
                    <th>Dirección</th>
                    <th>Ubicación</th>
                    <th>Equipo</th>
                    <th>Sensor</th>
 
                </tr>
            </thead>
            <tbody id="sensor-info-body">
                <!-- Los datos se cargarán vía AJAX -->
            </tbody>
        </table>
    </div>
</div>
        <?php
        return ob_get_clean();
    }
    
    public function get_sensor_data_ajax() {
        check_ajax_referer('sensor_premium_nonce', 'nonce');
        
        $db = $this->conectar_db();
        if(!$db) wp_send_json_error('Error de conexión a la base de datos');
        
        $local = isset($_POST['local']) ? $db->real_escape_string($_POST['local']) : '001';
    
        // Obtener los últimos 10 datos para el gráfico
        $query = $db->query(
            "SELECT 
                sensor,
                fecha,
                medida
            FROM datasensor_farmacia 
            WHERE (sensor LIKE '%temp%' OR sensor LIKE '%hum%')
            AND local = '$local'
            ORDER BY fecha DESC 
            LIMIT 60"
        );
    
        if(!$query) wp_send_json_error('Error en la consulta: ' . $db->error);
    
        $chart_data = [
            'temperature' => [],
            'humidity' => [],
            'labels' => []
        ];
    
        $rows = [];
        while ($row = $query->fetch_assoc()) {
            $rows[] = $row;  // Guardamos los datos en un array temporal
        }
    
        // Invertimos el orden para que aparezcan correctamente en el gráfico (del más antiguo al más reciente)
        $rows = array_reverse($rows);
    
        foreach ($rows as $row) {
            $is_temp = stripos($row['sensor'], 'temp') !== false;
            $type = $is_temp ? 'temperature' : 'humidity';
    
            $chart_data[$type][] = (float)$row['medida'];
            if ($is_temp) {
                $chart_data['labels'][] = date('H:i', strtotime($row['fecha']));
            }
        }
    
        // También obtener los últimos 10 registros para la tabla
        $query = $db->query(
            "SELECT 
                sensor,
                fecha,
                medida,
                min,
                max
            FROM datasensor_farmacia 
            WHERE (sensor LIKE '%temp%' OR sensor LIKE '%hum%')
            AND local = '$local'
            ORDER BY fecha DESC LIMIT 10"
        );
    
        $history_data = [];
        while ($row = $query->fetch_assoc()) {
            $history_data[] = $row;
        }
    
        wp_send_json_success([
            'chart_data' => $chart_data,
            'history_data' => $history_data
        ]);
    }
    
    
    public function get_full_sensor_data_ajax() {
        check_ajax_referer('sensor_premium_nonce', 'nonce');
        
        $db = $this->conectar_db();
        if (!$db) wp_send_json_error('Error de conexión a la base de datos');
        
        $local = isset($_POST['local']) ? $db->real_escape_string($_POST['local']) : '001';
        
        // Obtener el último registro de temperatura y humedad
        $query = $db->query(
            "SELECT 
                fecha,
                cliente,
                local,
                direccion,
                ubicacion,
                equipo,
                sensor,
                medida,
                escala,
                max,
                min
            FROM datasensor_farmacia 
            WHERE local = '$local' AND (sensor LIKE '%temp%' OR sensor LIKE '%hum%')
            ORDER BY fecha DESC"
        );
        
        if (!$query) wp_send_json_error('Error en la consulta: ' . $db->error);
        
        $data = [];
        $temp_found = false;
        $hum_found = false;
    
        while ($row = $query->fetch_assoc()) {
            if (!$temp_found && stripos($row['sensor'], 'temp') !== false) {
                $data[] = $row;
                $temp_found = true;
            }
            if (!$hum_found && stripos($row['sensor'], 'hum') !== false) {
                $data[] = $row;
                $hum_found = true;
            }
            if ($temp_found && $hum_found) break; // Salir del bucle si ya se encontraron ambos
        }
        
        wp_send_json_success($data);
    }
    
    private function verificar_alertas($temp_data, $hum_data) {
        $alertas = [];
        
        // Alertas de temperatura
        if($temp_data['medida'] > $temp_data['max']) {
            $alertas[] = [
                'tipo' => 'critica',
                'icono' => 'fas fa-exclamation-triangle',
                'mensaje' => 'Temperatura CRÍTICA: '.$temp_data['medida'].'°C (Máx: '.$temp_data['max'].'°C)'
            ];
        } elseif($temp_data['medida'] > ($temp_data['max'] * 0.9)) {
            $alertas[] = [
                'tipo' => 'advertencia',
                'icono' => 'fas fa-exclamation-circle',
                'mensaje' => 'Temperatura ALTA: '.$temp_data['medida'].'°C (Máx: '.$temp_data['max'].'°C)'
            ];
        } elseif($temp_data['medida'] < $temp_data['min']) {
            $alertas[] = [
                'tipo' => 'critica',
                'icono' => 'fas fa-exclamation-triangle',
                'mensaje' => 'Temperatura CRÍTICA: '.$temp_data['medida'].'°C (Mín: '.$temp_data['min'].'°C)'
            ];
        } elseif($temp_data['medida'] < ($temp_data['min'] * 1.1)) {
            $alertas[] = [
                'tipo' => 'advertencia',
                'icono' => 'fas fa-exclamation-circle',
                'mensaje' => 'Temperatura BAJA: '.$temp_data['medida'].'°C (Mín: '.$temp_data['min'].'°C)'
            ];
        }
        
        // Alertas de humedad
        if($hum_data['medida'] > $hum_data['max']) {
            $alertas[] = [
                'tipo' => 'critica',
                'icono' => 'fas fa-exclamation-triangle',
                'mensaje' => 'Humedad CRÍTICA: '.$hum_data['medida'].'% (Máx: '.$hum_data['max'].'%)'
            ];
        } elseif($hum_data['medida'] > ($hum_data['max'] * 0.85)) {
            $alertas[] = [
                'tipo' => 'advertencia',
                'icono' => 'fas fa-exclamation-circle',
                'mensaje' => 'Humedad ALTA: '.$hum_data['medida'].'% (Máx: '.$hum_data['max'].'%)'
            ];
        } elseif($hum_data['medida'] < $hum_data['min']) {
            $alertas[] = [
                'tipo' => 'critica',
                'icono' => 'fas fa-exclamation-triangle',
                'mensaje' => 'Humedad CRÍTICA: '.$hum_data['medida'].'% (Mín: '.$hum_data['min'].'%)'
            ];
        } elseif($hum_data['medida'] < ($hum_data['min'] * 1.15)) {
            $alertas[] = [
                'tipo' => 'advertencia',
                'icono' => 'fas fa-exclamation-circle',
                'mensaje' => 'Humedad BAJA: '.$hum_data['medida'].'% (Mín: '.$hum_data['min'].'%)'
            ];
        }
        
        return $alertas;
    }
    
    private function get_card_status($current, $min, $max, $is_humidity) {
        if($is_humidity) {
            if($current > $max) return 'estado-critico';
            if($current > ($max * 0.85)) return 'estado-alerta';
            if($current < $min) return 'estado-critico';
            if($current < ($min * 1.15)) return 'estado-alerta';
        } else {
            if($current > $max) return 'estado-critico';
            if($current > ($max * 0.9)) return 'estado-alerta';
            if($current < $min) return 'estado-critico';
            if($current < ($min * 1.1)) return 'estado-alerta';
        }
        return 'estado-normal';
    }
    
    private function get_status_text($current, $min, $max, $is_humidity) {
        if($is_humidity) {
            if($current > $max) return '<span class="status-badge danger">Crítica ▲</span>';
            if($current > ($max * 0.85)) return '<span class="status-badge warning">Alta ▲</span>';
            if($current < $min) return '<span class="status-badge danger">Crítica ▼</span>';
            if($current < ($min * 1.15)) return '<span class="status-badge warning">Baja ▼</span>';
        } else {
            if($current > $max) return '<span class="status-badge danger">Crítica ▲</span>';
            if($current > ($max * 0.9)) return '<span class="status-badge warning">Alta ▲</span>';
            if($current < $min) return '<span class="status-badge danger">Crítica ▼</span>';
            if($current < ($min * 1.1)) return '<span class="status-badge warning">Baja ▼</span>';
        }
        return '<span class="status-badge normal">Normal</span>';
    }
    
    private function formatear_fecha($fecha) {
        return date('d/m/Y H:i', strtotime($fecha));
    }
}

new SensorMonitorPremium();