jQuery(document).ready(function($) {
    // Variables globales
    let chartInstance = null;
    let refreshInterval = null;
    const REFRESH_TIME = 5000; // 5 segundos

    // Inicializar el dashboard
    function initDashboard() {
        const dashboard = $('.sensor-dashboard-premium');
        const local = dashboard.data('local');
        
        // Mostrar alertas con animación
        $('.alerta').each(function(index) {
            setTimeout(() => {
                $(this).addClass('show');
            }, index * 200);
        });
        
        // Cargar datos iniciales
        loadSensorData(local);
        
        // Configurar el modal
        setupModal(local);
        
        // Iniciar la actualización automática
        startAutoRefresh(local);
    }

    // Iniciar la actualización automática
    function startAutoRefresh(local) {
        // Detener cualquier intervalo previo
        if (refreshInterval) {
            clearInterval(refreshInterval);
        }
        
        // Configurar nuevo intervalo (5 segundos)
        refreshInterval = setInterval(() => {
            loadSensorData(local);
        }, REFRESH_TIME);
    }
// Función para determinar el estado (Normal, Crítica, etc.)
function getStatusText(value, min, max) {
    if (value > max) return 'Crítica ▲';
    if (value > max * 0.9) return 'Alta ▲';
    if (value < min) return 'Crítica ▼';
    if (value < min * 1.1) return 'Baja ▼';
    return 'Normal';
}

// Función para formatear la fecha de actualización
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
}

    // Cargar datos del sensor
    function loadSensorData(local) {
        $.ajax({
            url: sensorPremium.ajaxurl,
            type: 'POST',
            data: {
                action: 'get_sensor_data',
                local: local,
                nonce: sensorPremium.nonce
            },
            success: function(response) {
                if (response.success) {
                    const latestTemp = response.data.history_data.find(d => d.sensor.includes('temp'));
                    const latestHum = response.data.history_data.find(d => d.sensor.includes('hum'));
    
                    // 🟢 Actualizar tarjetas de temperatura y humedad
                    if (latestTemp) {
                        $('.sensor-card-premium.temp .card-value-premium').html(`${latestTemp.medida} <small>°C</small>`);
                        $('.sensor-card-premium.temp .stat-premium strong').eq(0).text(`${latestTemp.max}°`);
                        $('.sensor-card-premium.temp .stat-premium strong').eq(1).text(`${latestTemp.min}°`);
                        $('.sensor-card-premium.temp .stat-premium strong').eq(2).text(getStatusText(latestTemp.medida, latestTemp.min, latestTemp.max));
                        $('.sensor-card-premium.temp .card-footer-premium .hora').text(`Actualizado: ${formatDate(latestTemp.fecha)}`);
                    }
    
                    if (latestHum) {
                        $('.sensor-card-premium.hum .card-value-premium').html(`${latestHum.medida} <small>%</small>`);
                        $('.sensor-card-premium.hum .stat-premium strong').eq(0).text(`${latestHum.max}%`);
                        $('.sensor-card-premium.hum .stat-premium strong').eq(1).text(`${latestHum.min}%`);
                        $('.sensor-card-premium.hum .stat-premium strong').eq(2).text(getStatusText(latestHum.medida, latestHum.min, latestHum.max));
                        $('.sensor-card-premium.hum .card-footer-premium .hora').text(`Actualizado: ${formatDate(latestHum.fecha)}`);
                    }
    
                    // 🟢 Actualizar la tabla de histórico
                    updateHistoryTable(response.data.history_data);
    
                    // 🟢 Actualizar el gráfico con los nuevos datos
                    updateChart(
                        'sensorChart-' + local,
                        response.data.chart_data.labels,
                        response.data.chart_data.temperature,
                        response.data.chart_data.humidity
                    );
                }
            },
            error: function() {
                console.error('Error al cargar los datos del sensor');
            }
        });
    }
    

 // Actualizar el gráfico (con datos reales vs óptimos simulados)
function updateChart(canvasId, labels, tempData, humData) {
    const ctx = document.getElementById(canvasId).getContext('2d');
    
    // Generar datos óptimos simulados (variación dentro del rango ideal)
    const tempOptimaData = labels.map((_, i) => {
        // Valor base entre 25 y 30
        const base = 27.5;
        // Variación sinusoidal suave (±1.5 grados)
        const variation = Math.sin(i * 0.5) * 1.5;
        return base + variation;
    });
    
    const humOptimaData = labels.map((_, i) => {
        // Valor base entre 40 y 60
        const base = 50;
        // Variación sinusoidal suave (±5%)
        const variation = Math.sin(i * 0.3) * 5;
        return base + variation;
    });
    
    // Si el gráfico ya existe, actualizarlo
    if (chartInstance) {
        chartInstance.data.labels = labels;
        chartInstance.data.datasets[0].data = tempData;    // Real
        chartInstance.data.datasets[1].data = humData;     // Real
        chartInstance.data.datasets[2].data = tempOptimaData; // Óptimo
        chartInstance.data.datasets[3].data = humOptimaData;  // Óptimo
        chartInstance.update();
    } 
    // Si no existe, crearlo
    else {
        chartInstance = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [
                    // Temperatura real (línea principal)
                    {
                        label: 'Temperatura Real (°C)',
                        data: tempData,
                        borderColor: '#FF5252',
                        backgroundColor: 'rgba(255, 82, 82, 0.1)',
                        borderWidth: 3,
                        tension: 0.4,
                        fill: false,
                        pointBackgroundColor: '#FF5252',
                        pointRadius: 5,
                        pointHoverRadius: 7,
                        pointBorderWidth: 2,
                        pointBorderColor: '#FFFFFF',
                    },
                    // Humedad real (línea principal)
                    {
                        label: 'Humedad Real (%)',
                        data: humData,
                        borderColor: '#4285F4',
                        backgroundColor: 'rgba(66, 133, 244, 0.1)',
                        borderWidth: 3,
                        tension: 0.4,
                        fill: false,
                        pointBackgroundColor: '#4285F4',
                        pointRadius: 5,
                        pointHoverRadius: 7,
                        pointBorderWidth: 2,
                        pointBorderColor: '#FFFFFF',
                        yAxisID: 'y1'  // Este es el único cambio necesario
                    },
                    // Temperatura óptima (simulada)
                    {
                        label: 'Temperatura Óptima (°C)',
                        data: tempOptimaData,
                        borderColor: '#4CAF50',
                        borderWidth: 2,
                        borderDash: [5, 5],
                        tension: 0.1,
                        pointRadius: 0,
                        fill: false,
                    },
                    // Humedad óptima (simulada)
                    {
                        label: 'Humedad Óptima (%)',
                        data: humOptimaData,
                        borderColor: '#009688',
                        borderWidth: 2,
                        borderDash: [5, 5],
                        tension: 0.1,
                        pointRadius: 0,
                        fill: false,
                        yAxisID: 'y1'  // Este es el único cambio necesario
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                interaction: {
                    intersect: false,
                    mode: 'index'
                },
                plugins: {
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        titleFont: {
                            size: 14,
                            weight: 'bold'
                        },
                        bodyFont: {
                            size: 12
                        },
                        padding: 12,
                        cornerRadius: 8,
                        displayColors: true,
                    },
                    legend: {
                        display: true,
                        position: 'bottom',
                        labels: {
                            usePointStyle: true,
                            pointStyle: 'line'
                        }
                    }
                },
                scales: {
                    x: {
                        grid: {
                            display: false
                        },
                        ticks: {
                            color: '#666'
                        }
                    },
                    y: {
                        title: {
                            display: true,
                            text: 'Temperatura (°C)',
                            color: '#FF5252'
                        },
                        ticks: {
                            color: '#666'
                        },
                        grid: {
                            color: 'rgba(0, 0, 0, 0.05)'
                        },
                        min: Math.min(...tempData, ...tempOptimaData) - 2,
                        max: Math.max(...tempData, ...tempOptimaData) + 2
                    },
                    y1: {
                        position: 'right',
                        title: {
                            display: true,
                            text: 'Humedad (%)',
                            color: '#4285F4'
                        },
                        ticks: {
                            color: '#666'
                        },
                        grid: {
                            drawOnChartArea: false,
                            color: 'rgba(0, 0, 0, 0.05)'
                        },
                        min: Math.min(...humData, ...humOptimaData) - 5,
                        max: Math.max(...humData, ...humOptimaData) + 5
                    }
                }
            }
        });
    }
}

    // Actualizar la tabla de histórico
    function updateHistoryTable(data) {
        const tableBody = $('#history-table-body');
        tableBody.empty();
        
        data.forEach(function(row) {
            const isTemp = row.sensor.toLowerCase().includes('temp');
            const unit = isTemp ? '°C' : '%';
            const sensorType = isTemp ? 'Temperatura' : 'Humedad';
            
            let statusBadge;
            if (isTemp) {
                if (row.medida > row.max) statusBadge = '<span class="status-badge danger">Crítica ▲</span>';
                else if (row.medida > (row.max * 0.9)) statusBadge = '<span class="status-badge warning">Alta ▲</span>';
                else if (row.medida < row.min) statusBadge = '<span class="status-badge danger">Crítica ▼</span>';
                else if (row.medida < (row.min * 1.1)) statusBadge = '<span class="status-badge warning">Baja ▼</span>';
                else statusBadge = '<span class="status-badge normal">Normal</span>';
            } else {
                if (row.medida > row.max) statusBadge = '<span class="status-badge danger">Crítica ▲</span>';
                else if (row.medida > (row.max * 0.85)) statusBadge = '<span class="status-badge warning">Alta ▲</span>';
                else if (row.medida < row.min) statusBadge = '<span class="status-badge danger">Crítica ▼</span>';
                else if (row.medida < (row.min * 1.15)) statusBadge = '<span class="status-badge warning">Baja ▼</span>';
                else statusBadge = '<span class="status-badge normal">Normal</span>';
            }
            
            const date = new Date(row.fecha);
            const formattedDate = date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
            
            tableBody.append(
                '<tr>' +
                '<td>' + formattedDate + '</td>' +
                '<td>' + sensorType + '</td>' +
                '<td>' + row.medida + unit + '</td>' +
                '<td>' + statusBadge + '</td>' +
                '</tr>'
            );
        });
    }

    // Configurar el modal (opcional, si también quieres actualizar datos aquí)
    function setupModal(local) {
        const modal = $('#sensorDataModal');
        const btn = $('#view-more-btn');
        const closeBtn = $('.close-modal-premium');
        
        btn.click(function() {
            // Código para cargar datos en el modal (si es necesario)
        });
        
        // Cerrar modal
        closeBtn.click(function() {
            modal.hide();
        });
        
        // Cerrar al hacer clic fuera del modal
        $(window).click(function(event) {
            if (event.target === modal[0]) {
                modal.hide();
            }
        });
    }

    // Inicializar el dashboard
    initDashboard();



    function setupModal() {
        const modal = $('#sensorInfoModal');
        $('#view-sensor-info-btn').click(() => {
            modal.show();
            $.ajax({
                url: sensorPremium.ajaxurl,
                method: 'POST',
                data: {
                    action: 'get_full_sensor_data',
                    nonce: sensorPremium.nonce
                },
                success: (response) => {
                    if (response.success) {
                        const tbody = $('#sensor-info-body').empty();
                        response.data.forEach(row => tbody.append(`
                            <tr>
                                <td>${row.cliente}</td>
                                <td>${row.local}</td>
                                <td>${row.direccion}</td>
                                <td>${row.ubicacion}</td>
                                <td>${row.equipo}</td>
                                <td>${row.sensor}</td>
                            </tr>
                        `));
                    }
                }
            });
        });

        $('.close-modal-premium, #sensorInfoModal').click((e) => {
            if (e.target === modal[0] || e.target.classList.contains('close-modal-premium')) {
                modal.hide();
            }
        });
    }

    initDashboard();
    $(window).on('beforeunload', () => refreshInterval && clearInterval(refreshInterval));

});